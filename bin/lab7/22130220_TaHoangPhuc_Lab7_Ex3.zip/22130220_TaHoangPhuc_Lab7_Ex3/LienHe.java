package lab7.contact;

public interface LienHe {
  public String tenDau();

  public String tenCuoi();

  public String tieuDe();

  public String toChuc();

  public void setTenDau(String tenDau);

  public void setTieuDe(String tieuDe);

  public void setTenCuoi(String tencuoi);

  public void setToChuc(String toChuc);

}
